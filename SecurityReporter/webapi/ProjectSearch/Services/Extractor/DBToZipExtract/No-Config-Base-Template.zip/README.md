# Introduction 
This is the LaTeX source for the MLA pentest report. This repo contains project-specific information.

# Getting Started
In order to proceed with the build, you must already have the following installed:
1.	git (for pushing/pulling changes to enable collaboration)
2.	LaTeX (for building the final PDF from source files)
3.	coffee (because it's fun)

# Build and Test
Run the Build.bat batch script in the main directory. Use Clean.bat to delete intermediary build files.

# Contribute
This repo is project-specific. To alter the master LaTeX template, talk to Dusan.