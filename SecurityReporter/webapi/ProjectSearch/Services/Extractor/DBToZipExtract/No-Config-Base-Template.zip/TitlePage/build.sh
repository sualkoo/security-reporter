#!/bin/bash

echo "Author: Dusan"
echo "Do clean + build"


./clean.sh
pdflatex TitlePage.tex
pdflatex TitlePage.tex
pdflatex TitlePage.tex


