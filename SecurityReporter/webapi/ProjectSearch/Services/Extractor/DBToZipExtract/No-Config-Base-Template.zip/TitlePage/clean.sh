#!/bin/bash
echo "remove everything"

for i in *.aux *.log *.pdf *.toc *.log *.out *.vuln *.summary *.csv *.sum *~ *.swp *.xml *.bib; do
	test -f $i && rm -f "$i";
done;


##netreba subshell
#for i in $(ls *.aux *.log *.pdf *.toc *.log *.out *.vuln *.summary *.csv *.sum *~ *.swp *.xml *.bib 2>/dev/null ); do
#	test -f $i && echo $i;
#done;
