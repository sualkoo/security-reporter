#!/bin/bash
#
#		File:		Build.bat
#		Author: 	Dusan Repel (SHS TE DC CYS CSA)
#		Date:		02/09/2020
#
#
echo Recompile Title Page, included as pdf page

if [ $(stat -c "%a" TitlePage/clean.sh) != "774" ] ; then chmod 0774 TitlePage/clean.sh; fi
if [ $(stat -c "%a" TitlePage/build.sh) != "774" ] ; then chmod 0774 TitlePage/build.sh; fi

cd TitlePage
./build.sh
cd ..

if [ $(stat -c "%a" Clean.sh) != "774" ] ; then chmod 0774 Clean.sh; fi
./Clean.sh

echo "Compile LaTeX + build Bibliography + fix cross-references"
./chartValues.sh
pdflatex Main
bibtex   Main
pdflatex Main
pdflatex Main

