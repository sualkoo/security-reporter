#
#		File:		Clean.bat
#		Author: 	Dusan Repel (SHS TE DC CYS CSA)
#		Date:		02/09/2020
#		Unixified:      Jan Svitic
#
echo Clean intermediate build files
#

for i in *.aux *.pdf *.toc *.log *.out *.vuln *.summary; do
	test -f $i && rm -f "$i";
done;

for i in *.csv *.sum *~ *.swp *.bbl *.lot *.lof *.blg; do
	test -f $i && rm -f "$i";
done;
